<?php
/* Smarty version {Smarty::SMARTY_VERSION}, created on 2017-08-10 15:23:31
  from "/opt/lampp/htdocs/bigmee_new/application/views/templates/pages/product/product-filter.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32-dev-19',
  'unifunc' => 'content_598c2d1b6f8a76_51900739',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '07b4b4ce5428daca27abde6bfbefe0a3697e9127' => 
    array (
      0 => '/opt/lampp/htdocs/bigmee_new/application/views/templates/pages/product/product-filter.tpl',
      1 => 1502351225,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_598c2d1b6f8a76_51900739 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="row mobile-filter">
    <div class="col-md-12">
        <button class="btn btn-primary btn-sm pull-right" id="mobile-filter-btn"><i class="fa fa-search"></i> &nbsp;Filters</button>
    </div>
</div>

<div class="col-md-4 col-lg-3 col-sm-4 col-xs-12 product-main-filter">
    <div class="all-shop-sidebar">
        <form action="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
pages/product-view" class="product-filter-form">
            <input type="hidden" name="sort_by" id="hidden_sort_by" value="">
            <input type="hidden" name="limit" id="hidden_limit" value="">
            <div class="top-shop-sidebar">
                <h3 class="wg-title">Filter</h3>
            </div>
            <div class="shop-one">
                <h3 class="wg-title2">Categories</h3>
                <ul class="product-categories">
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['mcat_list']->value, 'main_category');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['main_category']->value) {
?>
                    <li class="cat-item">
                        <a href="javascript: void(0)">
                            <label class="inline2">
                                <input type="checkbox" name="base_cat[]" value="<?php echo $_smarty_tpl->tpl_vars['main_category']->value['mcat_id'];?>
" <?php if (in_array($_smarty_tpl->tpl_vars['main_category']->value['mcat_id'],$_smarty_tpl->tpl_vars['post_mcat']->value)) {?> checked <?php }?>>
                                       <?php echo $_smarty_tpl->tpl_vars['main_category']->value['mcat_name'];?>

                            </label>
                        </a>
                    </li>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>
   
                </ul> 
                <?php echo '<?php ';?>if(count($filter_bcat_list) != 0): <?php echo '?>';?>
                <h3 class="wg-title2">Business Category</h3>
                <ul class="product-categories">
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['filter_bcat_list']->value, 'b_cat');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['b_cat']->value) {
?>
                    <li class="cat-item">
                        <a href="javascript: void(0)">
                            <label class="inline2">
                                <input type="checkbox" name="sub_cat[]" value="<?php echo $_smarty_tpl->tpl_vars['b_cat']->value['bcat_id'];?>
" <?php if (in_array($_smarty_tpl->tpl_vars['b_cat']->value['bcat_id'],$_smarty_tpl->tpl_vars['post_bcat']->value)) {?> checked <?php }?>>
                                       <?php echo $_smarty_tpl->tpl_vars['b_cat']->value['bcat_name'];?>

                            </label>
                        </a>
                    </li>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>
  
                </ul>
                <?php echo '<?php ';?>endif;  <?php echo '?>';?>    
            </div>
            <div class="re-shop-one">
                <h3 class="wg-title2">Choose Price</h3>
                <div class="widget shop-filter">
                    <div class="info_widget">
                        <div class="price_filter">
                            <div id="slider-range"></div>
                            <div id="amount">
                                <input type="text" name="min_price" class="first_price" value="<?php echo $_smarty_tpl->tpl_vars['min_price']->value;?>
" />
                                <input type="text" name="max_price" class="last_price" value="<?php echo $_smarty_tpl->tpl_vars['max_price']->value;?>
"/>
                                <button class="button-shop filter-product" type="submit"><i class="fa fa-search search-icon"></i></button>
                            </div>

                        </div>
                    </div>							
                </div>
            </div>
    </div>
</div><?php }
}
